/* ###################################################################
**     Filename    : main.c
**     Project     : 2019_exam_question3
**     Processor   : MK20DX128VLH5
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2020-11-06, 22:11, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "ADC.h"
#include "AdcLdd1.h"
#include "RED_LED.h"
#include "BitIoLdd1.h"
#include "GREEN_LED.h"
#include "BitIoLdd2.h"
#include "BLUE_LED.h"
#include "BitIoLdd3.h"
#include "FC321.h"
#include "RealTimeLdd1.h"
#include "TU1.h"
#include "AS1.h"
#include "ASerialLdd1.h"
#include "Term1.h"
#include "Inhr1.h"
#include "ASerialLdd2.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
/* User includes (#include below this line is not maintained by Processor Expert) */


int rand(void);
void srand(unsigned int seed);

void delay(word delay_ms)
{
	word time;
	FC321_Reset();
	do
	{
		__asm("wfi"); // the micro-controller would be in low power mode

		FC321_GetTimeMS(&time);
	}while(time < delay_ms);
}

void LEDS_off()
{
	RED_LED_SetVal();
	GREEN_LED_SetVal();
	BLUE_LED_SetVal();
}

void send_string(const char *str)
  {

  	int i, len;
  	len = strlen(str); // returns the number of chars in str
  	byte err;
  	for (i= 0; i< len; i++) {
  		// send this character
  		do {
  			err = AS1_SendChar(str[i]);
  		} while (err != ERR_OK);
  	}
  }
/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */
	byte err;
	char c;

	uint16 adc_result;
	float voltage, time;
	int i;
	LEDS_off();
	char colour[3];
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */


  //Calibrate  ADC before use
  ADC_Calibrate(TRUE);

  for(;;)
  {
	  do{
	  		  err = AS1_RecvChar(&c); // component name = AS1
	  	  } while(err != ERR_OK); // the received byte is in the variable c
	  if (c == 't')
	  {
		  send_string("Analog Measurement:\n\r");
		  ADC_Measure(TRUE);
		  ADC_GetValue16(&adc_result);

//		  send_string("X = %d");
//		  send_string("adc_result");

//		  Term1_MoveTo(4, 3);
//		  Term1_SendStr("           ");
//		  Term1_MoveTo(5, 3);
//		  Term1_SendNum(adc_result);
//
//		  // Part c
//		  //Find voltage based on received adc_result
//		  voltage = ((float)0.6/(65536 - adc_result)) * adc_result+ 0.92;
//
//		  // Overflow error
//		  if (voltage <0)
//		  {
//			  voltage = 0;
//		  }
//		  Term1_MoveTo(1, 4);
//		  Term1_SendStr("v =       V");
//		  Term1_MoveTo(4, 4);
//		  Term1_SendStr("      ");
//		  Term1_MoveTo(5, 4);
//		  Term1_SendFloatNum(voltage);
//
//		  // Part d
//		  //Find the value of t
//		  time = ((float)(30702 - adc_result)/162.8);
//
//		  // Overflow error
//		  if (voltage <0)
//		  {
//			  voltage = 0;
//		  }
//		  Term1_MoveTo(1, 5);
//		  Term1_SendStr("t =       seconds");
//		  Term1_MoveTo(4, 5);
//		  Term1_SendStr("      ");
//		  Term1_MoveTo(5, 5);
//		  Term1_SendNum(time);
	  }
  }






  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
