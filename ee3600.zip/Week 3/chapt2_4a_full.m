clear all
close all hidden

syms s

%partial fractions expansion on portion 1 expression:

f = 24/( s*(s+7) );   %defining portion 1 function

A = subs( s*f, 0)    %solving for 'A'
A = vpa(A,5)   %cut down to 5 significant figures

B = subs( (s+7)*f, -7)    %solving for 'B'
B = vpa(B,5)   %cut down to 4 significant figures


%BELOW: using matlab's partial fractions function:
P1 = partfrac(f,'FactorMode','real')
vpa(P1,6)


g = -20/( s*(s+7)*(s^2+4) )
C = subs( s*g, 0)    %solving for 'C'
C = vpa(C,5)   %cut down to 5 significant figures

D = subs( (s+7)*g, -7)    %solving for 'D'
D = vpa(D,5)   %cut down to 4 significant figures

P2 = partfrac(g,'FactorMode','real')
vpa(P2,6)

X = vpa( 4/(s+7) + P1 + P2, 6 )    %X will be the full Laplace function in partial fractions form.

x = ilaplace(X)    %inverse Laplace transform of X will be x(t)

subs(x, 0)         %evalating the function x(t) at t = 0, just to make sure we get the correct initial value, which should be x(0) = 4

x_dash = diff(x)   %derivative of x(t)

subs(x_dash, 0)    %evalating the derivative function at t = 0, just to make sure we get the correct initial derivative value, which should be x'(0) = -4